import { useState } from "react";

export default function ComplaintForm() {

    const [formData,setFormData]=useState({

        title:"",
        description:"",
        category:"",
        priority:"MEDIUM",
        anonymous:false,
        againstUserId:"",
        attachment:null

    });

    const handleChange=(e)=>{

        const {name,value,type,checked}=e.target;

        setFormData(prev=>({

            ...prev,

            [name]:type==="checkbox"?checked:value

        }));

    }

    const handleFile=(e)=>{

        setFormData(prev=>({

            ...prev,

            attachment:e.target.files[0]

        }));

    }

    const handleSubmit=(e)=>{

        e.preventDefault();

        console.log(formData);

    }

    return(

        <form
            onSubmit={handleSubmit}
            className="space-y-6 rounded-3xl border border-white/10 bg-slate-950 p-8">

            <div>

                <label className="mb-2 block text-white">

                    Complaint Title

                </label>

                <input

                    name="title"

                    value={formData.title}

                    onChange={handleChange}

                    className="w-full rounded-xl border border-white/10 bg-slate-900 p-4 text-white"

                />

            </div>

            <div>

                <label className="mb-2 block text-white">

                    Description

                </label>

                <textarea

                    rows={6}

                    name="description"

                    value={formData.description}

                    onChange={handleChange}

                    className="w-full rounded-xl border border-white/10 bg-slate-900 p-4 text-white"

                />

            </div>

            <div className="grid gap-6 md:grid-cols-2">

                <div>

                    <label className="mb-2 block text-white">

                        Category

                    </label>

                    <select

                        name="category"

                        value={formData.category}

                        onChange={handleChange}

                        className="w-full rounded-xl border border-white/10 bg-slate-900 p-4 text-white">

                        <option value="">

                            Select Category

                        </option>

                        <option value="ACADEMIC">

                            Academic

                        </option>

                        <option value="FACULTY">

                            Faculty

                        </option>

                        <option value="INFRASTRUCTURE">

                            Infrastructure

                        </option>

                        <option value="HOSTEL">

                            Hostel

                        </option>

                    </select>

                </div>

                <div>

                    <label className="mb-2 block text-white">

                        Priority

                    </label>

                    <select

                        name="priority"

                        value={formData.priority}

                        onChange={handleChange}

                        className="w-full rounded-xl border border-white/10 bg-slate-900 p-4 text-white">

                        <option>LOW</option>

                        <option>MEDIUM</option>

                        <option>HIGH</option>

                    </select>

                </div>

            </div>

            <div>

                <label className="mb-2 block text-white">

                    Evidence

                </label>

                <input

                    type="file"

                    onChange={handleFile}

                    className="text-gray-300"

                />

            </div>

            <label className="flex items-center gap-3 text-white">

                <input

                    type="checkbox"

                    name="anonymous"

                    checked={formData.anonymous}

                    onChange={handleChange}

                />

                Submit Anonymously

            </label>

            <button

                className="w-full rounded-xl bg-gradient-to-r from-violet-600 to-blue-600 py-4 font-semibold text-white">

                Submit Complaint

            </button>

        </form>

    );

}