export default function AdminDashboard() {

    return (

        <h1 className="text-5xl font-bold text-white">

            Welcome Admin 🚀

        </h1>

    );

}