export default function StudentDashboard() {
    return (
        <h1 className="text-white text-5xl">
            Student Dashboard
        </h1>
    );
}